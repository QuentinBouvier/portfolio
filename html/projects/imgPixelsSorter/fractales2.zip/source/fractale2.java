import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class fractale2 extends PApplet {

/*
Programme de dessin d'une structure fractale d\u00e9riv\u00e9 d'un trait ou de plusieurs traits.
*/

int iterations;  //Le nombre d'it\u00e9rations de la structure
float baseTaillePixelVecteur; //La longueur en pixel de chaque vecteur.
Vecteur[] vecteur; //initialisation du tableau de vecteur
Repere repere; //initialisation du Rep\u00e8res.
int curseur;
Couleur[] couleur;
int longueurOrigine;
boolean dessinTermine;

public void setup() {  
  size (800,600);
  background(255);
  noLoop();
  
  couleur = new Couleur[4];  //Orange, Bleu, Rose, Vert, dans un tableau pour \u00eatre exploit\u00e9s
  couleur[0] = new Couleur(233,170,80);
  couleur[1] = new Couleur(81,70,223);
  couleur[2] = new Couleur(230,5,217);
  couleur[3] = new Couleur(99,221,33);
  
  iterations = 5;  // Nombre de r\u00e9p\u00e9titions de la "super" boucle.
  baseTaillePixelVecteur = 2;  //Longueur des vecteurs en pixel.
  repere = new Repere(width/2,height/2); //Position initiale.
  

  
}

public void draw() {
  background(255);
  
  longueurOrigine = 2; //Longueur de la chaine de base.
  
  vecteur = new Vecteur[longueurOrigine * PApplet.parseInt(pow(2,iterations))]; //Initialisation de la taille du tableau de vecteurs.
  
  vecteur[0] = new Vecteur(repere.origX, repere.origY, repere.origX, PApplet.parseFloat(repere.origY) - baseTaillePixelVecteur); //initialisation du premier vecteur
  vecteur[1] = vecteur[0].rotationInverse();
  //qui d\u00e9finit aussi la position de toute la structure.
  

  
  curseur = longueurOrigine; //place le curseur apr\u00e8s l'initialisation de la structure.
  
  for(int i=0; i < longueurOrigine; i++) {
    stroke(couleur[0].R, couleur[0].V, couleur[0].B);
    vecteur[i].tracerVecteur();
  }
  
  dessinTermine = false; //boolean de contr\u00f4le du dessin de la structure
  
  for(int i = 0; i < iterations; i++) {  //"Super"Boucle, d\u00e9finit la couleur de l'it\u00e9ration et stock la position d'origine de l'it\u00e9ration
    int origineIteration = curseur;
    int couleurCourante = (i+1) % 4;

     
    for(int j = 1; j <= origineIteration; j++) {   //Youplaboum.
      
      stroke(couleur[couleurCourante].R, couleur[couleurCourante].V, couleur[couleurCourante].B);
      if (curseur == longueurOrigine) { //Toute premi\u00e8re g\u00e9n\u00e9ration d'un vecteur par le programme. D\u00e9finition du protocole de dessin.
        vecteur[curseur] = vecteur[curseur-1].rotationInverse();
        vecteur[curseur].tracerVecteur();
      }
      else if(origineIteration == curseur) { //Premier vecteur de l'int\u00e9ration. Continuation du protocole.
        vecteur[curseur] = vecteur[curseur - 1].rotationHoraire();
        vecteur[curseur].tracerVecteur();
      }
     
      /*else if (origineIteration - j == 0) { //Dernier vecteur de l'it\u00e9ration.
        
        vecteur[curseur] = vecteur[curseur - 1].rotationHoraire();
        vecteur[curseur].tracerVecteur();
      }*/
    
      else { //tous les autres vecteurs.
      
        vecteur[curseur] = vecteur[curseur - 1].prochainVecteur(origineIteration, (curseur - origineIteration));
        vecteur[curseur].tracerVecteur();

         
      }
      curseur++;
    }
  }
  dessinTermine = true;

}

public void keyPressed() {
  
 if (dessinTermine) { //contr\u00f4le du dessin.
   if (key == CODED) {
     switch (keyCode) {
       
       case UP: //Augmenter taille en pixel des vecteurs (et donc de la structure).
         
         if (baseTaillePixelVecteur > 0 && baseTaillePixelVecteur < 1) {  //Passer en dessous de 1 pixel.
           baseTaillePixelVecteur *= 2;
           curseur = 1;
           
           redraw();
           
         }
         else {
           baseTaillePixelVecteur++;
           curseur = 1;
           
           redraw();
         }
         
         break;
         
       case DOWN: //Diminuer la taille en pixels.
       
         if (baseTaillePixelVecteur > 1) { //Passer en dessous des 1 pixels
           baseTaillePixelVecteur--;
           curseur = 1;
           
           redraw();
         }
         else if (baseTaillePixelVecteur <= 1 && baseTaillePixelVecteur > 0) {
           baseTaillePixelVecteur /=2;
           curseur = 1;
           
           redraw();
         }
         
         break;
         
       case RIGHT: //Ajouter une it\u00e9ration, augmenter la taille du tableau.
         iterations++;
         vecteur = (Vecteur[]) expand(vecteur, longueurOrigine * PApplet.parseInt(pow(2,iterations)));
         curseur = 1;
  
         redraw();
         break;
         
       case LEFT: //Retirer une it\u00e9ration, diminuer de moiti\u00e9 la taille du tableau.
         if (iterations > 0) {
           iterations--;
           int longueurArray = vecteur.length;
           vecteur = (Vecteur[]) subset(vecteur, longueurArray/2);
    
           curseur = 1;
           redraw();
         }
         break;
       
     }
     
   }  
 }
  
}

public void mouseDragged() {
  repere.origX += (mouseX - pmouseX);
  repere.origY += (mouseY - pmouseY);
  
}

public void mouseReleased() {
  curseur = 1;
  redraw(); 
}


class Repere { //classe de rep\u00e8re
  int origX, origY;
  
  Repere(int ox,int oy) {
    
    origX = ox;
    origY = oy;
  }
  
}

class Vecteur {
  float x1;
  float y1;
  float x2;
  float y2;
  
  Vecteur() {
    float x1;
    float x2;
    float y1;
    float y2;
  }
  
  Vecteur(float tempX1, float tempY1, float tempX2, float tempY2) {
    x1 = tempX1;
    y1 = tempY1;
    x2 = tempX2;
    y2 = tempY2;
  }
  
  public Vecteur rotationInverse() { //Formule math\u00e9matique de la rotation anti-horaire d'un vecteur.
    
    Vecteur v2 = new Vecteur();
    v2.x1 = this.x2;
    v2.y1 = this.y2;
    v2.x2 = this.x2 - (this.y2 - this.y1);
    v2.y2 = this.y2 - (this.x2 - this.x1);
    
    return v2;
  }
  
  public Vecteur rotationHoraire() { //Formule math\u00e9matique de la rotation horaire d'un vecteur.
    
   Vecteur v2 = new Vecteur();
   v2.x1 = this.x2;
   v2.y1 = this.y2;
   v2.x2 = this.x2 + (this.y2 - this.y1);
   v2.y2 = this.y2 + (this.x2 - this.x1);
   
   return v2; 
  }
  
  public Vecteur prochainVecteur (int positionOrigineIteration, int positionVecteur) {
    /*Fonction de d\u00e9finition d'un nouveau vecteur en fonction du vecteur en cours,
    de l'it\u00e9ration en cours, et du vecteur correspondant dans l'it\u00e9ration pr\u00e9c\u00e9dente.*/
    Vecteur prV = new Vecteur();

    int vecteurAPointer = positionOrigineIteration - positionVecteur; //r\u00e9cup\u00e9ration de la position du vecteur correspondant.
    
    Vecteur vTestH = vecteur[vecteurAPointer - 1].rotationHoraire(); //vecteurs de test pour la condition.
    Vecteur vTestI = vecteur[vecteurAPointer - 1].rotationInverse();
    

    if (vecteur[vecteurAPointer].x2 == vTestH.x2 && vecteur[vecteurAPointer].y2 == vTestH.y2) { //si les vecteurs \u00e0 pointer ont fait une rotation Horaire.
      prV = this.rotationInverse();

    }
    else if (vecteur[vecteurAPointer].x2 == vTestI.x2 && vecteur[vecteurAPointer].y2 == vTestI.y2) { //Si les vecteurs \u00e0 pointer ont fait une rotat Inverse
      prV = this.rotationHoraire();

    }
    
    return prV;
  }
  
  public void tracerVecteur() {

    line (this.x1, this.y1, this.x2, this.y2);
  }  
}

class Couleur {
  int R;
  int V;
  int B;
 
  Couleur(int tempR, int tempV, int tempB) {
    R = tempR;
    V = tempV;
    B = tempB;
  } 
  
}


  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "fractale2" });
  }
}
